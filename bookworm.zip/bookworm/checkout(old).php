<?php
include 'db_connect.php';
session_start();

$cust_id = $_SESSION['cust_id'];

if (!isset($cust_id)) {
    header('Location: login.php');
    exit();
}

// Fetch customer name based on cust_id
$cust_query = $conn->prepare("SELECT Cust_Name FROM customer WHERE Cust_ID = :cust_id");
$cust_query->execute(['cust_id' => $cust_id]);
$cust_data = $cust_query->fetch(PDO::FETCH_ASSOC);

if ($cust_data) {
    $cust_name = $cust_data['Cust_Name'];
} else {
    session_destroy();
    header('Location: login.php');
    exit();
}

$popup_message = "";

if (isset($_POST['order_btn'])) {
    $method = htmlspecialchars($_POST['method']);
    $placed_on = date('Y-m-d');

    $cart_total = 0;
    $cart_products = [];

    $cart_query = $conn->prepare("SELECT * FROM `cart` WHERE CustID = :cust_id");
    $cart_query->execute(['cust_id' => $cust_id]);

    if ($cart_query->rowCount() > 0) {
        while ($cart_item = $cart_query->fetch(PDO::FETCH_ASSOC)) {
            $cart_products[] = $cart_item['Title'] . ' (' . $cart_item['Quantity'] . ')';
            $sub_total = ($cart_item['UnitCost'] * $cart_item['Quantity']);
            $cart_total += $sub_total;
        }
    }

    if ($cart_total > 0) {
        $order_query = $conn->prepare("SELECT * FROM `payment` WHERE Cust_Name = :cust_name AND PaymentType = :method AND TotalCost = :cart_total AND Cust_ID = :cust_id");
        $order_query->execute([
            'cust_name' => $cust_name,
            'method' => $method,
            'cart_total' => $cart_total,
            'cust_id' => $cust_id
        ]);

        if ($order_query->rowCount() == 0) {
            $insert_order = $conn->prepare("INSERT INTO `payment` (PaymentType, PaymentDate, TotalCost, Cust_ID, Cust_Name, status) VALUES (:method, :placed_on, :cart_total, :cust_id, :cust_name, 'pending')");
            $insert_order->execute([
                'method' => $method,
                'placed_on' => $placed_on,
                'cart_total' => $cart_total,
                'cust_id' => $cust_id,
                'cust_name' => $cust_name
            ]);

            $clear_cart = $conn->prepare("DELETE FROM `cart` WHERE CustID = :cust_id");
            $clear_cart->execute(['cust_id' => $cust_id]);

            $popup_message = "Your order has been placed successfully!";
        }
    } else {
        $popup_message = "Your cart is empty. Please add items before placing an order.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Page</title>
    <link rel="stylesheet" href="css/checkout.css">
    <style>
        body {
            background-image: url('image/about1.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            background-attachment: fixed;
        }

        /* Popup Styles */
        .popup {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }

        .popup-content {
            background-color: #fff;
            margin: 15% auto;
            padding: 30px;
            border-radius: 10px;
            width: 300px;
            text-align: center;
            position: relative;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }

        .close {
            color: #aaa;
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 24px;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>
<body>

<!-- Popup Modal -->
<div id="popup" class="popup">
    <div class="popup-content">
        <span class="close">&times;</span>
        <p id="popup-text"></p>
    </div>
</div>

<?php
$backgroundImage = "image/about-background.jpg";
$activemenu = 'checkout';
include 'includes/header.php';
?>

<section class="display_order">
    <div class="display_order_wrapper">
        <h2>Ordered Products</h2>
        <?php
        $grand_total = 0;
        $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE CustID = :cust_id");
        $select_cart->execute(['cust_id' => $cust_id]);

        if ($select_cart->rowCount() > 0) {
            while ($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)) {
                $total_price = ($fetch_cart['UnitCost'] * $fetch_cart['Quantity']);
                $grand_total += $total_price;
        ?>
        <div class="single_order_product">
            <img src="./image/<?php echo $fetch_cart['image']; ?>" alt="Product Image">
            <div class="single_des">
                <h3><?php echo htmlspecialchars($fetch_cart['Title']); ?></h3>
                <p>Rs. <?php echo $fetch_cart['UnitCost']; ?></p>
                <p>Quantity: <?php echo $fetch_cart['Quantity']; ?></p>
            </div>
        </div>
        <?php
            }
        } else {
            echo '<p class="empty">Your cart is empty</p>';
        }
        ?>
        <div class="checkout_grand_total">
            GRAND TOTAL : <span>Rs. <?php echo $grand_total; ?>/-</span>
        </div>
    </div>
</section>

<section class="c">
    <form action="" method="post">
        <h2>Checkout Details</h2>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($cust_name); ?></p>
        <select name="method" required>
            <option value="" disabled selected>Select Payment Method</option>
            <option value="cash on delivery">Cash on Delivery</option>
            <option value="card">Card</option>
        </select>
        <input type="submit" value="Place Your Order" name="order_btn" class="product_btn">
    </form>
</section>

<script>
    const popupMessage = <?php echo json_encode($popup_message); ?>;

    if (popupMessage) {
        const popup = document.getElementById('popup');
        const popupText = document.getElementById('popup-text');
        const closeBtn = document.querySelector('.close');

        popupText.textContent = popupMessage;
        popup.style.display = 'block';

        closeBtn.onclick = () => popup.style.display = 'none';
        window.onclick = (e) => {
            if (e.target == popup) popup.style.display = 'none';
        }
    }
</script>

</body>
</html>


