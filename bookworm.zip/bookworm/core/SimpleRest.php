<?php
class SimpleRest {
    private $httpVersion = "HTTP/1.1";

    public function setHttpHeaders($contentType, $statusCode) {
        $statusMessage = $this->getHttpStatusMessage($statusCode);
        header($this->httpVersion . " " . $statusCode . " " . $statusMessage);
        header("Content-Type:" . $contentType);
    }

    public function getHttpStatusMessage($statusCode) {
        $httpStatus = array(
            200 => 'OK',
            201 => 'Created',
            204 => 'No Content',
            400 => 'Bad Request',
            401 => 'Unauthorized',
            403 => 'Forbidden',
            404 => 'Not Found',
            500 => 'Internal Server Error'
        );
        return $httpStatus[$statusCode] ?? $httpStatus[500];
    }
}
?>
