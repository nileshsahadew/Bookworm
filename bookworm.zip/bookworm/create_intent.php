<?php
require 'vendor/autoload.php';
\Stripe\Stripe::setApiKey('sk_test_51RH6HNPG7oE9x3QHlXgVutMxB6JKLSx3ctD9nWyVG8lZG1c3p9UZhKiwvpNgooUX8CPOgphHkDt05vr1m9EkgGHW00MKUYEzcW'); // Use env var in production

session_start();
include 'db_connect.php';

header('Content-Type: application/json');

$cust_id = $_SESSION['cust_id'] ?? null;

if (!$cust_id) {
    http_response_code(401);
    echo json_encode(['error' => 'User not logged in']);
    exit;
}

$total = 0;
$stmt = $conn->prepare("SELECT UnitCost, Quantity FROM cart WHERE CustID = :cust_id");
$stmt->execute(['cust_id' => $cust_id]);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $total += $row['UnitCost'] * $row['Quantity'];
}

if ($total <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Cart total is zero or invalid']);
    exit;
}

$intent = \Stripe\PaymentIntent::create([
    'amount' => $total * 100,
    'currency' => 'lkr',
    'automatic_payment_methods' => ['enabled' => true],
]);

echo json_encode(['clientSecret' => $intent->client_secret]);
