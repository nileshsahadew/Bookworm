<nav>
    <ul>
        <li class="<?= $activemenu == 'home' ? 'active' : '' ?>"><a href="index.php">Home</a></li>
        <li class="<?= $activemenu == 'review' ? 'active' : '' ?>"><a href="review.php">Review</a></li>
        <li class="<?= $activemenu == 'about' ? 'active' : '' ?>"><a href="about.php">About Us</a></li>
    </ul>
</nav>

<style>
    
    nav {
        background-image: url('<?= $backgroundImage ?>'); 
        background-size: cover; 
        background-position: center; 
        padding: 10px;
    }

    nav ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: space-around;
    }

    nav ul li {
        display: inline;
    }

    nav ul li a {
        color: white;
        text-decoration: none;
        padding: 10px 20px;
        display: block;
        background-color: rgba(0, 0, 0, 0.6); 
        border-radius: 5px;
    }

    nav ul li a:hover {
        background-color: rgba(255, 255, 255, 0.2); 
    }

    
    .active a {
        background-color: rgba(243, 156, 18, 0.8); 
        color: #fff;
    }
</style>