<footer style="text-align: center; padding: 20px; background-color: #222; color: #fff; width: 100%; height: 80px; box-sizing: border-box; display: flex; justify-content: center; align-items: center; gap: 20px;">
    <p style="margin: 0;">&copy; <?php echo date("Y"); ?> BOOKWORM. All rights reserved.</p>
    <a href="contactus.php" style="color: #FFD1DC; text-decoration: underline; margin: 0;">Contact Us</a>
</footer>


