<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-image: url('<?= $backgroundImage ?>');
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            height: 80px; 
            position: relative;
            z-index: 1000;
        }

        .navbar .logo img {
            width: 50px;
        }

        .navbar .menu {
            list-style-type: none;
            display: flex;
        }

        .navbar .menu li {
            margin: 0 15px;
        }

        .navbar .menu li a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            display: block;
            background-color: rgba(0, 0, 0, 0.6); 
            border-radius: 5px; 
        }

        .navbar .menu li a:hover {
            text-decoration: underline;
        }

        .navbar .right-menu {
            display: flex;
            align-items: center;
        }

        .navbar .right-menu a, .navbar .right-menu div {
            margin-left: 15px;
            color: white;
            text-decoration: none;
            font-size: 15px; 
            position: relative;
        }

        .navbar .right-menu a .fas, .navbar .right-menu div .fas {
            margin-right: 5px;
            color: white; 
        }

        .navbar .right-menu a span {
            font-size: 14px;
            color: red;
            position: absolute;
            top: -5px;
            right: -10px;
            background-color: white;
            color: black;
            padding: 2px 5px;
            border-radius: 50%;
        }

        .navbar .right-menu a:hover {
            text-decoration: none;
            color: #00f; 
        }

        .navbar .menu li.active a {
            background-color: rgba(128, 128, 128, 0.5); 
            color: white;
        }
    </style>
</head>

<div class="navbar">
    <div class="logo">
        <img src="book_logo.png" alt="" style="vertical-align: middle; width: 40px;">
        <span style="vertical-align: middle; color: whitesmoke; font-size: 15px;">Bookworm</span>
    </div>
    
    <ul class="menu">
        <li <?php if ($activemenu == "home") echo 'class="active"'; ?>>
            <a href="home.php">Home</a>
        </li>
        <li <?php if ($activemenu == "about") echo 'class="active"'; ?>>
            <a href="About.php">About</a>
        </li>
        <li <?php if ($activemenu == "shop") echo 'class="active"'; ?>>
            <a href="Shop.php">Shop</a>
        </li>
        <li <?php if ($activemenu == "orders") echo 'class="active"'; ?>>
            <a href="Orders.php">Orders</a>
        </li>
        <li <?php if ($activemenu == "review") echo 'class="active"'; ?>>
            <a href="review.php">Review</a>
        </li>
    </ul>

    <div class="right-menu">
        <a href="search.php"><i class="fas fa-search"></i></a>
        <a href="cart.php"><i class="fas fa-shopping-cart"></i></a>
        
        
        <?php if (isset($_SESSION['cust_id'])): ?>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="Register.php">New Login | Register</a>

            
        <?php endif; ?>
    </div>
</div>
<?php
if(isset($message)){
    foreach($message as $message){
        echo '
        <div class="message">
            <span>'.$message.'</span>
            <i class="fa-solid fa-xmark" onclick="this.parentElement.remove();"></i>
        </div>
    ';    
    } 
}
?>


 